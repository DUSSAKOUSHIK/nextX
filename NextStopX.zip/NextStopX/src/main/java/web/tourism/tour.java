package web.tourism;

import java.util.*;

import javax.persistence.Entity;
import javax.persistence.criteria.Selection;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import web.tourism.*;
import web.tourism.tourhibernate;
public class tour {

	public List<tourobj> getdetails() {
		
		SessionFactory sf=(SessionFactory) tourhibernate.getSessionFactory();
		Session s=sf.openSession();
		Transaction tx=s.beginTransaction();
		//tourobj h=new tourobj();
		
		String hql = "FROM tourobj"; 
		
		Query query = s.createQuery(hql);
		//query.setParameter("c", "Goa");// Assuming you want male students
		List<tourobj> results = query.list();
		int n=results.size();
		System.out.print(n);
		tx.commit();
		s.close();	
		
		
			//System.out.println(results.get(0).getInfo());
		return results;
	}
	public static void main(String args[]) {
		tour t=new tour();
		t.getdetails();
	}

}
