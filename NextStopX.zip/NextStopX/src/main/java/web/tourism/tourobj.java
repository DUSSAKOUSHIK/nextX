package web.tourism;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="india3")
public class tourobj {


	@Id
     @Column(name="place")
	// @GeneratedValue(strategy=GenerationType.IDENTITY)
	private String place;
	@Column(name="jpg")
   private String jpg;
	@Column(name="info")
   private String info;
	@Column(name="map")
   private String map;
	@Column(name="city")
   private String city;
	@Column(name="category")
	   private String category;
	 public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getJpg() {
		return jpg;
	}
	public void setJpg(String jpg) {
		this.jpg = jpg;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getMap() {
		return map;
	}
	public void setMap(String map) {
		this.map = map;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
}
